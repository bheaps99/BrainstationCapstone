# BrainstationCapstone

By Ben Heaps

Matrix Inversion Investigation

Sprint 1: Investigate possible Linear Regression Solutions to Matrix inversion, a preliminary investigation

please see slides Matrix Inversion Capstone.pptx
please see Jupyter Notebook Spring 1.ipynb

